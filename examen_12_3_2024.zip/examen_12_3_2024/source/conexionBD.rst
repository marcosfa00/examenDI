conexionBD module
=================

.. automodule:: conexionBD
   :members:
   :undoc-members:
   :show-inheritance:

    conexionBD
